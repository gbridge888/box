muban.海螺3.二级.content = '.hl-infos-content&&Text';
var rule = Object.assign(muban.海螺3,{
    title:'小猫咪',
    host:'https://xmaomi.net',
});