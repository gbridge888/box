// muban.海螺2.二级.content = '.hl-infos-content&&Text';
var rule = Object.assign(muban.海螺2,{
    title:'追剧喵',
    host:'https://zjmiao.com',
    搜索:'.search-list;a&&Text;.lazy&&data-original;.deployment&&Text;a&&href',
});